public class State2 implements State {
	private static State me = null;

	private State2() {

	}

	@Override
	public State transition(int event) {
		if(event == 0) {
			return State1.getInstance();
		}
		return null;
	}

	public static State getInstance() {
		if(me == null) {
			me = new State2();
		}
		return me;
	}

	@Override
	public String getName() {
		return "State 2";
	}
}
