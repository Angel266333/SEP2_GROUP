public class Calculate implements State {
	@Override
	public State transition(int event) {
		return null;
	}

	@Override
	public String getName() {
		return "Calculate";
	}
}
