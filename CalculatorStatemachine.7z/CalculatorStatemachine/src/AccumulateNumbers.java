public class AccumulateNumbers implements State {
	@Override
	public State transition(int event) {
		if(event == Event.push0) {
			if(Memory.getFromDisplay().size() == 1 && Memory.getFromDisplay().contains('0')) {
				return this;
			}
		}

		if(event < 10) {
			char c = ("" + event).charAt(0);
			Memory.addChar(c);
		}

		if(event == Event.pushEquals) {
			if(Memory.getFromMemory() == 0D) {
				return this;
			}
			Memory.
		}
	}

	@Override
	public String getName() {
		return "Accumulate Numbers";
	}
}
