public class Event {
	public static int push0 = 0;
	public static int push1 = 1;
	public static int push2 = 2;
	public static int push3 = 3;
	public static int push4 = 4;
	public static int push5 = 5;
	public static int push6 = 6;
	public static int push7 = 7;
	public static int push8 = 8;
	public static int push9 = 9;

	public static int pushEquals = 10;
	public static int pushPlus = 11;
	public static int pushMinus = 12;
	public static int pushMultiply = 13;
	public static int pushDivide = 14;

	public static int pushPoint = 15;
	public static int pushOn = 16;
}
