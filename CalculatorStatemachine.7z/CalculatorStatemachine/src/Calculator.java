import java.lang.reflect.Field;
import java.util.*;

public class Calculator {
	private State currentState = State1.getInstance();
	private ArrayList<String> events;

	public Calculator() {
		events = new ArrayList<>();
		for(Field f : Event.class.getDeclaredFields()) {
			events.add(f.getName());
		}
	}

	private void transition(int event) {
		currentState = currentState.transition(event);
	}

	public void run() {
		Scanner scanner = new Scanner(System.in);

		while(true) {
			String s = scanner.nextLine();
			if(events.contains(s)) {
				transition(events.indexOf(s));
				System.out.println(currentState.getName());
			}
			else if(s.equals("quit")) {
				break;
			}
		}
	}

	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		calculator.run();
	}
}
