import java.util.ArrayList;

public class Memory {
	private static ArrayList<Character> display = new ArrayList<>();
	private static double memory = 0;
	public static char operation = '+';

	public static void addChar(char c) {
		if(display.contains('.') && c == '.') {
			return;
		}
		display.add(c);
	}

	public static void moveToMemory() {
		char[] chars = new char[display.size()];
		int i = 0;
		for(Character ch : display) {
			chars[i++] = ch;
		}
		memory = Double.parseDouble(new String(chars));
		display.clear();
	}

	public static double getFromMemory() {
		return memory;
	}

	public static ArrayList<Character> getFromDisplay() {
		return display;
	}

	public static void printDisplay() {

	}

	public static void main(String[] args) {
		addChar('2');
		addChar('.');
		addChar('3');
		addChar('.');
		addChar('2');
		moveToMemory();
		addChar('4');
		addChar('.');
		addChar('7');
		moveToMemory();
	}
}
