public interface State {
	State transition(int event);
	String getName();
}
