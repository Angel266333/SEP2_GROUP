public class State1 implements State {
	private static State me = null;

	private State1() {

	}

	@Override
	public State transition(int event) {
		if(event == 0) {
			return State2.getInstance();
		}
		return null;
	}

	public static State getInstance() {
		if(me == null) {
			me = new State1();
		}
		return me;
	}

	@Override
	public String getName() {
		return "State 1";
	}
}
