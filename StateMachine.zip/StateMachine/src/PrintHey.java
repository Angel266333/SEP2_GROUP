public class PrintHey implements MachineAction {
	@Override
	public void act() {
		System.out.println("Hey");
	}
}
