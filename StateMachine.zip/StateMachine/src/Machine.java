public class Machine {
	int[][][] relations;
	MachineAction[] actions;
	int state;
	static int ARRIVE = 0;
	static int LEAVE = 1;
	static int GONE = 0;
	static int PRESENT = 1;

	public Machine() {
		relations = new int[2][2][2];
		actions = new MachineAction[2];
		actions[0] = new PrintHey();
		actions[1] = new PrintBye();
		state = 0;
		relations[0][0][0] = 1;
		relations[0][0][1] = 0;
		relations[0][1][0] = 0;
		relations[0][1][1] = -1;
		relations[1][0][0] = 1;
		relations[1][0][1] = -1;
		relations[1][1][0] = 0;
		relations[1][1][1] = 1;
	}

	public void input(int i) {
		int nstate = relations[state][i][0];
		int action = relations[state][i][1];
		if(action > -1) {
			actions[action].act();
		}
		state = nstate;
	}

	public static void main(String[] args) {
		Machine m = new Machine();
		m.input(Machine.ARRIVE);
		m.input(Machine.LEAVE);
		m.input(Machine.LEAVE);
		m.input(Machine.LEAVE);
		m.input(Machine.ARRIVE);
		m.input(Machine.ARRIVE);
		m.input(Machine.LEAVE);
	}
}
