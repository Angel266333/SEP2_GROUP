public interface MachineAction {
	void act();
}
