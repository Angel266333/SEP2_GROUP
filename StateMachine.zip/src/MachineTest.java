public class MachineTest {
	public static void main(String[] args) {
		MyMachine m = new MyMachine();
		m.input(MyMachine.ARRIVE);
		m.input(MyMachine.ARRIVE);
		m.input(MyMachine.LEAVE);
		m.input(MyMachine.LEAVE);
		m.input(MyMachine.ARRIVE);
		m.input(MyMachine.LEAVE);
	}
}
