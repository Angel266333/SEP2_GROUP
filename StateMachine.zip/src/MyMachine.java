public class MyMachine extends StateMachine {
	//Events
	public static int ARRIVE = 0;
	public static int LEAVE = 1;

	//States
	private static int GONE = 0;
	private static int PRESENT = 1;

	public MyMachine() {
		super(2, 2);
		MachineAction hey = new PrintHey();
		MachineAction bye = new PrintBye();
		setTransition(GONE, ARRIVE, PRESENT, hey);
		setTransition(GONE, LEAVE, GONE, null);
		setTransition(PRESENT, ARRIVE, PRESENT, null);
		setTransition(PRESENT, LEAVE, GONE, bye);
	}
}
