public class PrintBye implements MachineAction {
	@Override
	public void act() {
		System.out.println("Bye");
	}
}
