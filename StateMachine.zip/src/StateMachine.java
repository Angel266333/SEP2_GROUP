public abstract class StateMachine {
	private int[][] transitions;
	private MachineAction[][] actions;
	private int state = 0;

	protected StateMachine(int transitionCount, int eventCount) {
		//Table of transition relations [from-state][event] returns to-state
		transitions = new int[transitionCount][eventCount];
		//Table of action relations [state][event] returns action
		actions = new MachineAction[transitionCount][eventCount];
	}

	protected void setTransition(int fromState, int event, int toState, MachineAction action) {
		transitions[fromState][event] = toState;
		actions[fromState][event] = action;
	}

	public void input(int i) {
		MachineAction ma = actions[state][i];
		state = transitions[state][i];
		if(ma != null) {
			ma.act();
		}
	}
}
