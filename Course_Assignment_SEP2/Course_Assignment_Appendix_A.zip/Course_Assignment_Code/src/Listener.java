public interface Listener {

	void onOutput(String userList);
	
}
