
public class ConcreteListener implements Listener {

	@Override
	public void onOutput(String userList) {
	System.out.println(userList);
	}

}
